package com.example.assignment.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "likedInterests")
public class LikedInterest {
    @PrimaryKey (autoGenerate = true)
    @NonNull
    public int id;

    private String interestName;

    public void setInterestName(String interestName) {
        this.interestName = interestName;
    }
    public String getInterestName() {
        return interestName;
    }
    public int getId() {
        return id;
    }
}
