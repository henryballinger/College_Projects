package com.example.assignment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignment.models.LikedInterest;
import com.example.assignment.models.Venue;
import com.example.assignment.models.VenueInterestLink;

import java.util.List;

public class VenuesAdapter extends RecyclerView.Adapter<VenuesAdapter.ViewHolder> {
    // Variables
    private final LayoutInflater venueInflater;
    private List<Venue> venuesList;
    private static VenuesAdapter.ClickListener mapsClickListener;

    VenuesAdapter(Context context, List<Venue> venuesList) {
        venueInflater = LayoutInflater.from(context);
        this.venuesList = venuesList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(venueInflater.inflate(R.layout.venues_recycler_item, parent, false)); }
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) { holder.bindData(position); }
    @Override
    public int getItemCount() { return venuesList.size(); }

    void updateData(List<Venue> venues) {
        this.venuesList = venues;
        notifyDataSetChanged();
    }

    // Method to return GPS coordinates of venue at position
    public double[] getGPSAtPosition(int position) {
        return new double[] { venuesList.get(position).getLatitude(), venuesList.get(position).getLongitude() };
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView venueTextView;
        private final TextView scoreTextView;
        private final TextView distanceTextView;
        List<LikedInterest> likedInterests;

        ViewHolder(View itemView) {
            super(itemView);
            // Assigning variables to layout elements
            venueTextView = itemView.findViewById(R.id.venue_recycler_item);
            scoreTextView = itemView.findViewById(R.id.interestScore);
            distanceTextView = itemView.findViewById(R.id.distanceToVenue);
            ImageView mapsImageView = itemView.findViewById(R.id.mapsIcon);
            // Assigning on click to maps icons
            mapsImageView.setOnClickListener(view -> mapsClickListener.onItemClick(view, getAdapterPosition()));
            // Assigning list of liked interests, retrieved from venues activity
            likedInterests = VenuesActivity.getLikedInterests();
        }

        void bindData(int position) {
            Venue venue = venuesList.get(position);
            // Get venue name
            String venueName = venue.getVenueName();

            // Set text to be venue name
            venueTextView.setText(venueName);

            // Call function to calculate distance between device and venue
            // First argument - Get latitude and longitude of venue to be displayed
            // Second argument - Get latitude and longitude of device from venues activity
            float distanceToVenue = distanceBetween(getGPSAtPosition(position), VenuesActivity.getGPS());

            // Set text to display distance, formatted to only display 2 decimal places
            @SuppressLint("DefaultLocale") String distance = String.format("%.2f", distanceToVenue) + "km";
            distanceTextView.setText(distance);

            // Create list of interests associated with venue, retrieved from venues activity
            List<VenueInterestLink> venueInterests = VenuesActivity.getVenueInterestLinks(venueName);

            // Variable for calculating interest compatibility score
            int count = 0;
            // Loop through interests associated with venue, getting interest name for each
            // Loop through liked interests, checking if the interest names are a match
            // If so, incrementing the counter;
            for (VenueInterestLink venueInterest : venueInterests) {
                String interestName = venueInterest.getInterestName();
                for (LikedInterest likedInterest : likedInterests) {
                    if (interestName.equals(likedInterest.getInterestName())) {
                        count++;
                    }
                }
            }
            // Calculating the score as a percentage, setting the text to reflect
            int score = (count * 100) / venueInterests.size();
            String scorePercent = score + "%";
            scoreTextView.setText(scorePercent);
        }
    }

    // Method for calculating distance between device and venue
    // Using android built in method for calculating distance between two coordinates
    public static float distanceBetween(double[] venueGPS, double[] deviceGPS) {
        float[] distance = new float[1];
        Location.distanceBetween(venueGPS[0], venueGPS[1], deviceGPS[0], deviceGPS[1], distance);
        return distance[0]/1000;
    }

    // Assigning click listener to maps icon
    public void setOnItemClickListener(VenuesAdapter.ClickListener clickListener) { VenuesAdapter.mapsClickListener = clickListener; }
    public interface ClickListener { void onItemClick(View v, int position); }
}
