package com.example.assignment;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.assignment.db.AppDatabase;
import com.example.assignment.db.InterestDAO;
import com.example.assignment.db.LikedInterestDAO;
import com.example.assignment.models.Interest;
import com.example.assignment.models.LikedInterest;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class InterestsActivity extends AppCompatActivity {
    private static final int createInterest = 1;
    RecyclerView unlikedInterestsRecycler;
    RecyclerView likedInterestsRecycler;
    InterestsAdapter interestsAdapter;
    LikedInterestsAdapter likedInterestsAdapter;
    InterestDAO unlikedInterestDAO;
    LikedInterestDAO likedInterestDAO;
    FloatingActionButton addInterestFAB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.interests);

        // Setup access to database
        unlikedInterestDAO = Room.databaseBuilder(this, AppDatabase.class, "AppDatabase")
                .allowMainThreadQueries().build().getInterestDAO();
        likedInterestDAO = Room.databaseBuilder(this, AppDatabase.class, "AppDatabase")
                .allowMainThreadQueries().build().getLikedInterestDAO();
        // Assign two recycler views to local variables
        unlikedInterestsRecycler = findViewById(R.id.interests_unliked_recycler);
        likedInterestsRecycler = findViewById(R.id.interests_liked_recycler);
        // Set layout managers for recycler views
        unlikedInterestsRecycler.setLayoutManager(new LinearLayoutManager(this));
        likedInterestsRecycler.setLayoutManager(new LinearLayoutManager(this));
        // Create and set adapters for recycler views
        interestsAdapter = new InterestsAdapter(this, new ArrayList<>());
        likedInterestsAdapter = new LikedInterestsAdapter(this, new ArrayList<>());
        unlikedInterestsRecycler.setAdapter(interestsAdapter);
        likedInterestsRecycler.setAdapter(likedInterestsAdapter);

        // Call method to load interests from database
        loadInterests();

        // Set onClick for the not liked interests, calling insertDelete function with the interest name
        interestsAdapter.setOnItemClickListener((v, position) -> {
            String interest = interestsAdapter.getWordAtPosition(position);
            insertDelete(interest,false);
        });
        // Set onClick for the liked interests, calling insertDelete function with the interest name
        likedInterestsAdapter.setOnItemClickListener((v, position) -> {
            String interest = likedInterestsAdapter.getWordAtPosition(position);
            insertDelete(interest, true);
        });

        // Assign floating action button to variable, set onClick to load add interest activity
        addInterestFAB = findViewById(R.id.addInterestFAB);
        addInterestFAB.setOnClickListener(view -> {
            Intent addIntent = new Intent(InterestsActivity.this, AddInterestActivity.class);
            startActivityForResult(addIntent, createInterest);
        });
    }

    // Handle result fom add interest activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        loadInterests();
    }

    // Populate not liked and liked adapters with interests from the database
    private void loadInterests() {
        interestsAdapter.updateData(unlikedInterestDAO.getInterests());
        likedInterestsAdapter.updateData(likedInterestDAO.getLikedInterests());
    }

    // Method to insert or delete interest
    // interest name and boolean indicating whether the interest is coming from the liked list or not
    public void insertDelete(String interest, boolean liked) {
        // If interest is in liked list, create new Interest, insert into that table in database
        // Delete from liked interest table in database
        if (liked) {
            Interest interestToInsert = new Interest();
            interestToInsert.setInterestName(interest);
            unlikedInterestDAO.insert(interestToInsert);
            likedInterestDAO.deleteByInterestName(interest);
        }
        // If interest is not liked, create new LikedInterest, insert into liked interest table in database
        // Delete from interests table in database
        else {
            LikedInterest interestToMove = new LikedInterest();
            interestToMove.setInterestName(interest);
            likedInterestDAO.insert(interestToMove);
            unlikedInterestDAO.deleteByInterestName(interest);
        }
        // Load interests again
        loadInterests();
    }
}