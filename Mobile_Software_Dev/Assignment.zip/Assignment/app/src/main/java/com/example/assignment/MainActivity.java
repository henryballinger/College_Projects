package com.example.assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
    }

    // Handle on click for all elements on homepage
    // Create and start explicit intent for correct activity
    public void homepageLink(View view) {
        Intent linkIntent = new Intent();
        switch (view.getId()) {
            case (R.id.moodsBtn):
                linkIntent = new Intent(this, MoodsActivity.class);
                break;
            case (R.id.interestsBtn):
                linkIntent = new Intent(this, InterestsActivity.class);
                break;
            case (R.id.checkInBtn):
                linkIntent = new Intent(this, CheckInActivity.class);
                break;
            case (R.id.aboutLink):
                linkIntent = new Intent(this, AboutActivity.class);
                break;
        }
        startActivity(linkIntent);
    }
}