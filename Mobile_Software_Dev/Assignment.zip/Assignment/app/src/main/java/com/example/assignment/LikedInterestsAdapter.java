package com.example.assignment;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.assignment.models.LikedInterest;

import java.util.List;

public class LikedInterestsAdapter extends RecyclerView.Adapter<LikedInterestsAdapter.ViewHolder> {
    private final LayoutInflater likedInterestInflater;
    private List<LikedInterest> likedInterestList;
    private static ClickListener clickListener;

    LikedInterestsAdapter(Context context, List<LikedInterest> interestList) {
        likedInterestInflater = LayoutInflater.from(context);
        this.likedInterestList = interestList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(likedInterestInflater.inflate(R.layout.interests_recycler_item, parent, false)); }
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.bindData(position);
    }
    @Override
    public int getItemCount() {
        return likedInterestList.size();
    }

    void updateData(List<LikedInterest> interests) {
        this.likedInterestList = interests;
        notifyDataSetChanged();
    }

    public String getWordAtPosition(int position) { return likedInterestList.get(position).getInterestName(); }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView interestTextView;

        ViewHolder(View itemView) {
            super(itemView);
            interestTextView = itemView.findViewById(R.id.interest_recycler_item);
            itemView.setOnClickListener(view -> clickListener.onItemClick(view, getAdapterPosition()));
        }

        void bindData(int position) {
            // Attach data to recycler view at position
            LikedInterest interest = likedInterestList.get(position);
            String interestName = interest.getInterestName();
            interestTextView.setText(interestName);
        }
    }

    // On clicks for liked interests in recycler view
    public void setOnItemClickListener(ClickListener clickListener) {
        LikedInterestsAdapter.clickListener = clickListener;
    }
    public interface ClickListener {
        void onItemClick(View v, int position);
    }
}
