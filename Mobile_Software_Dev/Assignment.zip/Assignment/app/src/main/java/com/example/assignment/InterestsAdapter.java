package com.example.assignment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignment.models.Interest;

import java.util.List;

public class InterestsAdapter extends RecyclerView.Adapter<InterestsAdapter.ViewHolder> {
    private final LayoutInflater interestInflater;
    private List<Interest> interestList;
    private static ClickListener clickListener;

    InterestsAdapter(Context context, List<Interest> interestList) {
        interestInflater = LayoutInflater.from(context);
        this.interestList = interestList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(interestInflater.inflate(R.layout.interests_recycler_item, parent, false)); }
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) { holder.bindData(position); }
    @Override
    public int getItemCount() { return interestList.size(); }

    void updateData(List<Interest> interests) {
        this.interestList = interests;
        notifyDataSetChanged();
    }

    public String getWordAtPosition(int position) { return interestList.get(position).getInterestName(); }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView interestTextView;

        ViewHolder(View itemView) {
            super(itemView);
            interestTextView = itemView.findViewById(R.id.interest_recycler_item);
            itemView.setOnClickListener(view -> clickListener.onItemClick(view, getAdapterPosition()));
        }

        void bindData(int position) {
            // Attach data to recycler view at position
            Interest interest = interestList.get(position);
            String interestName = interest.getInterestName();
            interestTextView.setText(interestName);
        }
    }

    // On clicks for interests in recycler view
    public void setOnItemClickListener(ClickListener clickListener) {
        InterestsAdapter.clickListener = clickListener;
    }
    public interface ClickListener {
        void onItemClick(View v, int position);
    }
}
