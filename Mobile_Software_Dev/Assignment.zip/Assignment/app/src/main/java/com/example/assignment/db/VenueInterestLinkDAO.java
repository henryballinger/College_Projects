package com.example.assignment.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.assignment.models.VenueInterestLink;

import java.util.List;

@Dao
public interface VenueInterestLinkDAO {
    @Insert
    void insert(VenueInterestLink... venueInterestLinks);

    @Query("select * from venueInterestLink where venueName = :venueName")
    List<VenueInterestLink> getVenueInterestByName(String venueName);
}