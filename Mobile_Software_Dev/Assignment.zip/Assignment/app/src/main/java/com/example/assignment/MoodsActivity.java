package com.example.assignment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;

import java.text.DateFormat;
import java.util.Date;

public class MoodsActivity extends AppCompatActivity {
    private static final String mood = "mood";
    private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 34;
    private static final int REQUEST_CHECK_SETTINGS = 0x1;
    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 50000;
    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS / 2;
    private final static String KEY_REQUESTING_LOCATION_UPDATES = "requesting-location-updates";
    private final static String KEY_LOCATION = "location";
    private final static String KEY_LAST_UPDATED_TIME_STRING = "last-updated-time-string";
    private FusedLocationProviderClient fusedLocationProviderClient;
    private SettingsClient settingsClient;
    private LocationRequest locationRequest;
    private LocationSettingsRequest locationSettingsRequest;
    private LocationCallback locationCallback;
    private static Location currentLocation;
    private Boolean requestingLocationUpdates;
    private String lastUpdateTime;
    private double[] gpsCoordinates;
    private ProgressBar progressBar;
    private TextView findLocationText;
    private TextView moodTagline;
    private Button[] moodLinks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.moods);
        // Assign variables and call methods for requesting location
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        requestingLocationUpdates = true;
        updateValuesFromBundle(savedInstanceState);
        settingsClient = LocationServices.getSettingsClient(this);
        createLocationRequest();
        createLocationCallback();
        buildLocationSettingsRequest();
        // Assign variables for layout elements
        progressBar = findViewById(R.id.progressBar);
        findLocationText = findViewById(R.id.findingLocation);
        moodTagline = findViewById(R.id.moodsTagline);
        moodLinks = new Button[] {findViewById(R.id.adventurous), findViewById(R.id.chill),
                findViewById(R.id.cultural), findViewById(R.id.hungry), findViewById(R.id.party),
                findViewById(R.id.surprise)};
        gpsCoordinates = new double[2];
    }

    // When user clicks a mood
    public void showVenues(View view) {
        // Create a new intent to the Venues page
        Intent venuesIntent = new Intent(this, VenuesActivity.class);
        // Get the id of the button pressed, check which mood it corresponds to
        // Put the mood in the intent as extra
        switch (view.getId()) {
            case (R.id.adventurous):
                venuesIntent.putExtra(mood, getString(R.string.adventurous));
                break;
            case (R.id.chill):
                venuesIntent.putExtra(mood, getString(R.string.chill));
                break;
            case (R.id.cultural):
                venuesIntent.putExtra(mood, getString(R.string.cultural));
                break;
            case (R.id.hungry):
                venuesIntent.putExtra(mood, getString(R.string.hungry));
                break;
            case (R.id.party):
                venuesIntent.putExtra(mood, getString(R.string.party));
                break;
            case (R.id.surprise):
                venuesIntent.putExtra(mood, getString(R.string.surprise));
                break;
        }
        // Put the GPS coordinates of the device in the intent as extra
        venuesIntent.putExtra("gps", gpsCoordinates);
        // Start intent
        startActivity(venuesIntent);
    }

    private void logGPS() {
        // Check that location has been found (i.e. not null
        if (currentLocation != null) {
            // Hide progress bar and text about finding location
            progressBar.setVisibility(View.GONE);
            findLocationText.setVisibility(View.GONE);
            // Show tag line for page and all mood link buttons
            moodTagline.setVisibility(View.VISIBLE);
            for (Button moodLink : moodLinks) {
                moodLink.setVisibility(View.VISIBLE);
            }
            // Assign gps array to hold latitude and longitude of current location
            gpsCoordinates = new double[] {currentLocation.getLatitude(), currentLocation.getLongitude()};
        }
    }

    private void updateValuesFromBundle(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            if (savedInstanceState.keySet().contains(KEY_REQUESTING_LOCATION_UPDATES)) {
                requestingLocationUpdates = savedInstanceState.getBoolean(KEY_REQUESTING_LOCATION_UPDATES); }
            if (savedInstanceState.keySet().contains(KEY_LOCATION)) {
                currentLocation = savedInstanceState.getParcelable(KEY_LOCATION); }
            if (savedInstanceState.keySet().contains(KEY_LAST_UPDATED_TIME_STRING)) {
                lastUpdateTime = savedInstanceState.getString(KEY_LAST_UPDATED_TIME_STRING); }
            logGPS();
        }
    }

    // Create location request, assigning the predefined interval, fastest interval and priority level for the request
    // High accuracy used as the distance to venues within a city will need to be exact
    // As we are only requesting very 10-20 seconds, battery life should not be affected too much
    private void createLocationRequest() {
        locationRequest = new LocationRequest();
        locationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        locationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    private void createLocationCallback() {
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                lastUpdateTime = DateFormat.getTimeInstance().format(new Date());
                currentLocation = locationResult.getLastLocation();
                logGPS();
            }
        };
    }

    private void buildLocationSettingsRequest() {
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(locationRequest);
        locationSettingsRequest = builder.build();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CHECK_SETTINGS && resultCode == Activity.RESULT_CANCELED) {
            requestingLocationUpdates = false;
            logGPS();
        }
    }

    private void startLocationUpdates() {
        // Begin by checking if the device has the necessary location settings
        settingsClient.checkLocationSettings(locationSettingsRequest)
                .addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
                    @SuppressLint("MissingPermission")
                    @Override
                    public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                        fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper()); }
                })
                .addOnFailureListener(this, e -> {
                    int statusCode = ((ApiException) e).getStatusCode();
                    switch (statusCode) {
                        case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                            try {
                                ResolvableApiException rae = (ResolvableApiException) e;
                                rae.startResolutionForResult(MoodsActivity.this, REQUEST_CHECK_SETTINGS);
                            } catch (IntentSender.SendIntentException ignored) { }
                            break;
                        case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                            Toast.makeText(MoodsActivity.this, getResources().getString(R.string.fix_in_settings), Toast.LENGTH_LONG).show();
                            requestingLocationUpdates = false;
                    }
                });
    }

    private void stopLocationUpdates() {
        // If location updates are not being requested, nothing to stop
        if (!requestingLocationUpdates) { return; }

        // Stop location updates
        fusedLocationProviderClient.removeLocationUpdates(locationCallback)
                .addOnCompleteListener(this, task -> requestingLocationUpdates = false);
    }

    @Override
    public void onResume() {
        super.onResume();
        // If requested and have permission, start location updates, otherwise, request permission
        if (requestingLocationUpdates && checkPermissions()) { startLocationUpdates(); }
        else if (!checkPermissions()) { requestPermissions(); }
        logGPS();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopLocationUpdates();
    }

    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putBoolean(KEY_REQUESTING_LOCATION_UPDATES, requestingLocationUpdates);
        savedInstanceState.putParcelable(KEY_LOCATION, currentLocation);
        savedInstanceState.putString(KEY_LAST_UPDATED_TIME_STRING, lastUpdateTime);
        super.onSaveInstanceState(savedInstanceState);
    }

    private void showSnackbar(final int mainTextStringId, final int actionStringId, View.OnClickListener listener) {
        Snackbar.make(findViewById(android.R.id.content), getString(mainTextStringId),
                Snackbar.LENGTH_INDEFINITE).setAction(getString(actionStringId), listener).show();
    }
    // Check if app has permission to use location services
    private boolean checkPermissions() {
        int permissionState = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        return permissionState == PackageManager.PERMISSION_GRANTED;
    }
    // Ask user for permission to use location services
    private void requestPermissions() {
        boolean shouldProvideRationale =
                ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.ACCESS_FINE_LOCATION);
        if (shouldProvideRationale) { showSnackbar(R.string.permission_rationale,
                android.R.string.ok, view -> ActivityCompat.requestPermissions(MoodsActivity.this,
                        new String[]{ Manifest.permission.ACCESS_FINE_LOCATION }, REQUEST_PERMISSIONS_REQUEST_CODE));
        } else {
            ActivityCompat.requestPermissions(MoodsActivity.this,
                    new String[]{ Manifest.permission.ACCESS_FINE_LOCATION }, REQUEST_PERMISSIONS_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && requestingLocationUpdates) {
                startLocationUpdates();
            } else {
                showSnackbar(R.string.permission_denied_explanation, R.string.settings, view -> {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", BuildConfig.APPLICATION_ID, null);
                intent.setData(uri);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent); });
            }
        }
    }
}
