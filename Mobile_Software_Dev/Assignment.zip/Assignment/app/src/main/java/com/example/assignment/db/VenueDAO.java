package com.example.assignment.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.assignment.models.Venue;

import java.util.List;

@Dao
public interface VenueDAO {
    @Insert
    void insert(Venue... venues);

    @Query("select * from venues where mood = :mood")
    List<Venue> getVenues(String mood);
}