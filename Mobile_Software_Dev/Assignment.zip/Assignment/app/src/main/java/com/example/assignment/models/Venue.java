package com.example.assignment.models;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "venues")
public class Venue {
    @PrimaryKey (autoGenerate = true)
    @NonNull
    public int id;

    private String venueName;
    private String mood;
    private float latitude;
    private float longitude;

    public void setVenueName(String venueName) { this.venueName = venueName; }
    public String getVenueName() { return venueName; }
    public void setMood(String mood) { this.mood = mood; }
    public String getMood() { return mood; }
    public void setLatitude(Float latitude) { this.latitude = latitude; }
    public Float getLatitude() { return latitude; }
    public void setLongitude(Float longitude) { this.longitude = longitude; }
    public Float getLongitude() { return longitude; }
}