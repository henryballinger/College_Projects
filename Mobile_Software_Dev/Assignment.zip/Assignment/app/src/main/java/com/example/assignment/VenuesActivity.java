package com.example.assignment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import com.example.assignment.db.AppDatabase;
import com.example.assignment.db.LikedInterestDAO;
import com.example.assignment.db.VenueDAO;
import com.example.assignment.db.VenueInterestLinkDAO;
import com.example.assignment.models.LikedInterest;
import com.example.assignment.models.Venue;
import com.example.assignment.models.VenueInterestLink;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.view.View;

public class VenuesActivity extends AppCompatActivity {
    // Variables
    RecyclerView venuesRecycler;
    VenuesAdapter venuesAdapter;
    VenueDAO venuesDAO;
    static LikedInterestDAO likedInterestDAO;
    static VenueInterestLinkDAO venueInterestLinkDAO;
    static List<LikedInterest> likedInterests;
    static double[] gps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.venues);

        // Retrieve intent to get extras
        Intent venueIntent = getIntent();
        // Retrieve mood extra from the intent
        String mood = venueIntent.getStringExtra("mood");
        // Retrieve the GPS array from the intent
        gps = venueIntent.getDoubleArrayExtra("gps");

        // Get title element from layout, assign mood to be the text of the title
        TextView title = findViewById(R.id.venueTitle);
        title.setText(mood);

        // Set up DAO's for Venues, Liked Interests and Venue Interests for accessing database
        venuesDAO = Room.databaseBuilder(this, AppDatabase.class, "AppDatabase")
                .allowMainThreadQueries().build().getVenueDAO();
        likedInterestDAO = Room.databaseBuilder(this, AppDatabase.class, "AppDatabase")
                .allowMainThreadQueries().build().getLikedInterestDAO();
        venueInterestLinkDAO = Room.databaseBuilder(this, AppDatabase.class, "AppDatabase")
                .allowMainThreadQueries().build().getVenueInterestLinkDAO();

        // Assign liked interests list to all liked interests in database
        likedInterests = likedInterestDAO.getLikedInterests();
        // Assign variable to hold recycler view for easy access and manipulation
        venuesRecycler = findViewById(R.id.venues_recycler);
        // Assign layout and adapter to recycler view
        venuesRecycler.setLayoutManager(new LinearLayoutManager(this));
        venuesAdapter = new VenuesAdapter(this, new ArrayList<>());
        venuesRecycler.setAdapter(venuesAdapter);
        // Load venues for appropriate mood
        loadVenues(mood);
        // On click listener for maps icons
        venuesAdapter.setOnItemClickListener((v, position) -> {
            // Assign array for holding GPS coordinates of venue
            double[] venueGPS = venuesAdapter.getGPSAtPosition(position);
            // Create Uri to open Maps application at venue latitude and longitude
            Uri location = Uri.parse("geo:" + venueGPS[0] + "," + venueGPS[1] + "?z=14");
            // Create explicit intent, add uri to intent, start
            Intent mapIntent = new Intent(Intent.ACTION_VIEW);
            mapIntent.setData(location);
            startActivity(mapIntent);
        });
    }

    private void loadVenues(String mood) {
        // Have an array of moods in English from the strings resource
        String[] englishMoods = getResources().getStringArray(R.array.surprise_moods_english);
        // Variable for accessing array
        int index;

        // If mood is 'Surprise Me', generate random number
        // Grab that random mood from array of English moods
        if (mood.equals(getResources().getString(R.string.surprise))) {
            index = new Random().nextInt(5);
            mood = englishMoods[index];
        }
        else {
            // If app has been translated to Irish, create list from Irish moods array
            // Find the index of the Irish mood in that list
            // Get the corresponding English mood
            // This is needed for querying the database
            if (Locale.getDefault().getDisplayLanguage().equals("Gaeilge")) {
                List<String> irishMoods = Arrays.asList(getResources().getStringArray(R.array.surprise_moods_irish));
                index = irishMoods.indexOf(mood);
                mood = englishMoods[index];
            }
        }

        // Update data in venue adapter with venues returned from DB
        // Sending mood to get the venues related to that mood
        venuesAdapter.updateData(venuesDAO.getVenues(mood));
    }

    // Method for returning the gps coordinates of device to the adapter for calculating distances
    public static double[] getGPS() {
        return gps;
    }

    // Method for returning the list of liked interests to the adapter for calculating venue score
    public static List<LikedInterest> getLikedInterests() {
        return likedInterests;
    }

    // Method for returning list of interests associated with venue to adapter for calculating venue score
    public static List<VenueInterestLink> getVenueInterestLinks(String venueName) {
        return venueInterestLinkDAO.getVenueInterestByName(venueName);
    }
}



