package com.example.assignment.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.assignment.models.Interest;

import java.util.List;

@Dao
public interface InterestDAO {

    @Insert
    void insert(Interest... interests);

    @Query("select * from interests")
    List<Interest> getInterests();

    @Query("delete from interests where interestName = :interestID")
    void deleteByInterestName(String interestID);
}

