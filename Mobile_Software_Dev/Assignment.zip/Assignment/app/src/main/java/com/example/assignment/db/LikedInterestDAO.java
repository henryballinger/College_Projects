package com.example.assignment.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.assignment.models.LikedInterest;

import java.util.List;

@Dao
public interface LikedInterestDAO {

    @Insert
    void insert(LikedInterest... LikedInterests);

    @Query("select * from likedInterests order by id desc")
    List<LikedInterest> getLikedInterests();

    @Query("delete from likedInterests where interestName = :interestName")
    void deleteByInterestName(String interestName);
}



