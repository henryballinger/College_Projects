package com.example.assignment;

import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.assignment.db.AppDatabase;
import com.example.assignment.db.LikedInterestDAO;
import com.example.assignment.models.LikedInterest;

public class AddInterestActivity extends AppCompatActivity {
    private EditText addInterestEditText;
    private LikedInterestDAO likedInterestDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_interest);

        // Setup access to database
        likedInterestDAO = Room.databaseBuilder(this, AppDatabase.class, "AppDatabase")
                .allowMainThreadQueries().build().getLikedInterestDAO();
        // Assign variables for layout elements
        addInterestEditText = findViewById(R.id.interestDescription);
        Button saveButton = findViewById(R.id.saveInterestBtn);
        // Assign onClick to save button
        saveButton.setOnClickListener(view -> {
            // Get the string value of what the user has entered
            String interestName = addInterestEditText.getText().toString();

            // Check if user has entered anything
            if (interestName.length() != 0) {
                // Create new liked interest and set the name to be what the user entered
                LikedInterest likedInterest = new LikedInterest();
                likedInterest.setInterestName(interestName);

                // Insert into database, return with result_ok code. Catch errors
                try {
                    likedInterestDAO.insert(likedInterest);
                    setResult(RESULT_OK);
                    finish();
                } catch (SQLiteConstraintException ignored) { }
            }
        });
    }
}
