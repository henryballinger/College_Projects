package com.example.assignment.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.assignment.models.Interest;
import com.example.assignment.models.Venue;
import com.example.assignment.models.VenueInterestLink;
import com.example.assignment.models.LikedInterest;

@Database(entities = {Interest.class, LikedInterest.class, Venue.class, VenueInterestLink.class}, version = 1)

public abstract class AppDatabase extends RoomDatabase {
    public abstract InterestDAO getInterestDAO();
    public abstract LikedInterestDAO getLikedInterestDAO();
    public abstract VenueDAO getVenueDAO();
    public abstract VenueInterestLinkDAO getVenueInterestLinkDAO();
}
