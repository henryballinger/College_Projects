package com.example.assignment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class CheckInActivity extends AppCompatActivity {
    ImageView qrCode;
    private static final int picID = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkin_activity);
        // Assign variable to layout element
        qrCode = findViewById(R.id.QRCode);
    }

    // Start camera using implicit intent and receive back image captured
    public void loadCamera(View view) {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, picID);
    }

    // Handle result from cameraIntent
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Get photo from result and set element on page to display
        Bitmap qrPhoto = (Bitmap) data.getExtras().get("data");
        qrCode.setImageBitmap(qrPhoto);
    }

    // Create and start activity to load main activity (homepage)
    public void goHome(View view) {
        Intent homeIntent = new Intent(this, MainActivity.class);
        startActivity(homeIntent);
    }
}
